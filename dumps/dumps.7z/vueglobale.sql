-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mer 22 Février 2017 à 15:27
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `capacityplanning`
--

-- --------------------------------------------------------

--
-- Structure de la table `vueglobale`
--

DROP TABLE IF EXISTS `vueglobale`;
CREATE TABLE IF NOT EXISTS `vueglobale` (
  `Environnement` varchar(50) NOT NULL,
  `Label` varchar(50) NOT NULL,
  `Valeur` varchar(250) DEFAULT NULL,
  `Date_Releve` date NOT NULL,
  `Site` varchar(50) NOT NULL,
  `id_reference` int(11) NOT NULL AUTO_INCREMENT,
  `Custom1` varchar(100) DEFAULT NULL,
  `Custom2` varchar(100) DEFAULT NULL,
  `Custom3` varchar(100) DEFAULT NULL,
  `Custom4` varchar(100) DEFAULT NULL,
  `Custom5` varchar(100) DEFAULT NULL,
  `Custom6` varchar(100) DEFAULT NULL,
  `Custom7` varchar(100) DEFAULT NULL,
  `Custom8` varchar(100) DEFAULT NULL,
  `Custom9` varchar(100) DEFAULT NULL,
  `Custom10` varchar(100) DEFAULT NULL,
  `Custom11` varchar(100) DEFAULT NULL,
  `Custom12` varchar(100) DEFAULT NULL,
  `Custom13` varchar(100) DEFAULT NULL,
  `Custom14` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_reference`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `vueglobale`
--

INSERT INTO `vueglobale` (`Environnement`, `Label`, `Valeur`, `Date_Releve`, `Site`, `id_reference`, `Custom1`, `Custom2`, `Custom3`, `Custom4`, `Custom5`, `Custom6`, `Custom7`, `Custom8`, `Custom9`, `Custom10`, `Custom11`, `Custom12`, `Custom13`, `Custom14`) VALUES
('TSM', 'Bandes', NULL, '2017-02-01', 'Ampère', 1, '30', '12', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
